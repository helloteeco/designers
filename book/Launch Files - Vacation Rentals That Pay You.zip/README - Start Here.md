# Launch Files — Vacation Rentals That Pay You

This zip has ONLY what you need to launch. Nothing else. (The complete archive — alternate titles, manuscript sources, build scripts — lives on GitHub, PR #12, if you ever need it.)

## What's here

```
├── The Launch Checklist.pdf      ← print this, work top to bottom
├── AMAZON_LISTING_KIT.md         ← everything you paste into KDP: description, keywords, categories, pricing
├── LAUNCH_PLAYBOOK.md            ← the 6-week plan for you + a Claude session (context prompt on page 1)
├── Title Options - Side by Side.png  ← only if you want to run the IG poll tonight
├── book/                         ← the 4 files you upload to Amazon
│   ├── ... - Kindle.epub                 → Kindle eBook: manuscript file
│   ├── ... - Ebook Cover.jpg             → Kindle eBook: cover
│   ├── ... - Print Interior 6x9.pdf      → Paperback: interior (also the hardcover interior)
│   └── ... - Print Cover Wrap.pdf        → Paperback: cover (263pp, spine + bleed + barcode zone built in)
├── bonus-pack-upload/            ← put this whole folder behind the email form at teeco.co/bookbonus
│   ├── 18 branded PDFs
│   └── Deal Analysis Calculator.xlsx
└── BONUS_PACK_README.md          ← YOUR map of the bonus pack + the few items only you can add. Not for readers.
```

## The order tomorrow

1. Checklist in hand → AMAZON_LISTING_KIT.md open → upload ebook, then paperback, order the proof.
2. Hardcover after the proof passes: same interior PDF; cover template from kdp.amazon.com/cover-calculator (6×9, white, 263 pages) with the wrap art placed on it.
3. Bonus Pack live at teeco.co/bookbonus before launch day (upload `bonus-pack-upload/`, add your personal items per BONUS_PACK_README).
4. Read your book. Get the releases signed. Then go.
